/*********************************************************************
 * METALC_BASE.H - Base definitions for Metal C exit programming
 * 
 * This header provides common utilities, type definitions, and
 * system control block mappings for IBM Metal C exit development.
 * 
 * Usage: #include "metalc_base.h"
 * 
 * Note: All structures use #pragma pack(1) for byte alignment
 *       matching mainframe DSECT layouts.
 *********************************************************************/

#ifndef METALC_BASE_H
#define METALC_BASE_H

/*-------------------------------------------------------------------
 * Standard type definitions for z/OS
 *-------------------------------------------------------------------*/

typedef unsigned char      uint8_t;
typedef signed char        int8_t;
typedef unsigned short     uint16_t;
typedef signed short       int16_t;
typedef unsigned int       uint32_t;
typedef signed int         int32_t;
typedef unsigned long long uint64_t;
typedef signed long long   int64_t;
typedef unsigned int       size_t;
typedef unsigned int       uintptr_t;

/* Pointer types for 31-bit and 64-bit modes */
#ifdef __LP64__
typedef uint64_t           ptr_t;
#else
typedef uint32_t           ptr_t;
#endif

/*-------------------------------------------------------------------
 * Common constants
 *-------------------------------------------------------------------*/

#define NULL               ((void *)0)
#define TRUE               1
#define FALSE              0

/*-------------------------------------------------------------------
 * Inline utility functions (no C library available in Metal C)
 *-------------------------------------------------------------------*/

/**
 * memcpy_inline - Copy memory
 * @dest: Destination pointer
 * @src:  Source pointer
 * @n:    Number of bytes to copy
 */
static inline void *memcpy_inline(void *dest, const void *src, size_t n) {
    unsigned char *d = (unsigned char *)dest;
    const unsigned char *s = (const unsigned char *)src;
    while (n--) {
        *d++ = *s++;
    }
    return dest;
}

/**
 * memset_inline - Fill memory with a constant byte
 * @s: Memory pointer
 * @c: Byte value to set
 * @n: Number of bytes to set
 */
static inline void *memset_inline(void *s, int c, size_t n) {
    unsigned char *p = (unsigned char *)s;
    while (n--) {
        *p++ = (unsigned char)c;
    }
    return s;
}

/**
 * memcmp_inline - Compare memory areas
 * @s1: First memory area
 * @s2: Second memory area
 * @n:  Number of bytes to compare
 * Returns: <0 if s1<s2, 0 if equal, >0 if s1>s2
 */
static inline int memcmp_inline(const void *s1, const void *s2, size_t n) {
    const unsigned char *p1 = (const unsigned char *)s1;
    const unsigned char *p2 = (const unsigned char *)s2;
    while (n--) {
        if (*p1 != *p2) {
            return *p1 - *p2;
        }
        p1++;
        p2++;
    }
    return 0;
}

/**
 * memcmp_secure - Constant-time memory comparison (timing-attack safe)
 * @s1: First memory area
 * @s2: Second memory area
 * @n:  Number of bytes to compare
 * Returns: 0 if equal, non-zero if different
 */
static inline int memcmp_secure(const void *s1, const void *s2, size_t n) {
    const unsigned char *p1 = (const unsigned char *)s1;
    const unsigned char *p2 = (const unsigned char *)s2;
    unsigned char result = 0;
    while (n--) {
        result |= *p1++ ^ *p2++;
    }
    return result;
}

/**
 * strlen_inline - Calculate string length
 * @s: Null-terminated string
 * Returns: Length not including null terminator
 */
static inline size_t strlen_inline(const char *s) {
    const char *p = s;
    while (*p) p++;
    return (size_t)(p - s);
}

/**
 * strncmp_inline - Compare strings up to n characters
 * @s1: First string
 * @s2: Second string
 * @n:  Maximum characters to compare
 * Returns: <0 if s1<s2, 0 if equal, >0 if s1>s2
 */
static inline int strncmp_inline(const char *s1, const char *s2, size_t n) {
    while (n && *s1 && (*s1 == *s2)) {
        s1++;
        s2++;
        n--;
    }
    if (n == 0) return 0;
    return *(unsigned char *)s1 - *(unsigned char *)s2;
}

/**
 * is_blank - Check if character array is all blanks
 * @s: Character array (not null-terminated)
 * @n: Length to check
 * Returns: 1 if all blanks, 0 otherwise
 */
static inline int is_blank(const char *s, size_t n) {
    while (n--) {
        if (*s++ != ' ') return 0;
    }
    return 1;
}

/**
 * pad_blank - Pad character array with blanks
 * @s:   Character array
 * @len: Current content length
 * @max: Total field size
 */
static inline void pad_blank(char *s, size_t len, size_t max) {
    while (len < max) {
        s[len++] = ' ';
    }
}

/*-------------------------------------------------------------------
 * Bit manipulation macros
 *-------------------------------------------------------------------*/

#define BIT_SET(val, bit)      ((val) |= (bit))
#define BIT_CLEAR(val, bit)    ((val) &= ~(bit))
#define BIT_TEST(val, bit)     (((val) & (bit)) != 0)
#define BIT_TOGGLE(val, bit)   ((val) ^= (bit))

/* High-order bit for parameter list end marker */
#define PARM_LAST_MASK         0x80000000

/*-------------------------------------------------------------------
 * z/OS System Control Blocks
 *-------------------------------------------------------------------*/

#pragma pack(1)

/* PSA - Prefixed Save Area (low memory) */
#define PSA_BASE               0
#define FLCCVT                 0x10        /* Offset to CVT pointer */
#define PSATOLD                0x21C       /* Current TCB pointer   */
#define PSAAOLD                0x224       /* Current ASCB pointer  */

/* CVT - Communication Vector Table */
struct cvt {
    char           cvtfix[128];      /* +0   Fixed portion            */
    void          *cvttcbp;          /* +128 TCB/ASCB words pointer   */
    /* ... many fields omitted ... */
    char           cvtprodn[8];      /* +404 Product name             */
    char           cvtprodo[8];      /* +412 Product owner            */
    char           cvtprodv[8];      /* +420 Product version          */
    /* Note: Actual CVT is much larger; add fields as needed */
};

/* ASCB - Address Space Control Block (partial) */
struct ascb {
    char           ascbid[4];        /* +0   'ASCB'                   */
    void          *ascbfwdp;         /* +4   Forward chain            */
    void          *ascbbwdp;         /* +8   Backward chain           */
    uint16_t       ascbasid;         /* +36  ASID                     */
    char           ascbjbni[8];      /* +172 Job name (initiator)     */
    char           ascbjbns[8];      /* +180 Job name (started)       */
    /* Add fields as needed */
};

/* TCB - Task Control Block (partial) */
struct tcb {
    void          *tcbrbp;           /* +0   RB pointer               */
    void          *tcbpie;           /* +4   PIE pointer              */
    void          *tcbdeb;           /* +8   DEB pointer              */
    void          *tcbtio;           /* +12  TIOT pointer             */
    uint32_t       tcbcmp;           /* +16  Completion code          */
    /* Add fields as needed */
};

/* TIOT - Task I/O Table (partial) */
struct tiot {
    char           tiocnjob[8];      /* +0   Job name                 */
    char           tiocstep[8];      /* +8   Step name                */
    /* DD entries follow */
};

#pragma pack()

/*-------------------------------------------------------------------
 * System access macros
 *-------------------------------------------------------------------*/

/* Get CVT pointer */
#define GET_CVT()              (*(struct cvt **)FLCCVT)

/* Get current TCB pointer */
#define GET_TCB()              (*(struct tcb **)PSATOLD)

/* Get current ASCB pointer */
#define GET_ASCB()             (*(struct ascb **)PSAAOLD)

/* Get TCB/ASCB words from CVT */
static inline void **get_tcb_ascb_words(void) {
    struct cvt *cvt = GET_CVT();
    return (void **)((char *)cvt + 0);  /* CVTTCBP offset */
}

/*-------------------------------------------------------------------
 * Time and date utilities
 *-------------------------------------------------------------------*/

/* SMF time is in 0.01 second units since midnight */
#define SMF_TIME_HOUR(t)       ((t) / 360000)
#define SMF_TIME_MINUTE(t)     (((t) / 6000) % 60)
#define SMF_TIME_SECOND(t)     (((t) / 100) % 60)
#define SMF_TIME_HUNDREDTH(t)  ((t) % 100)

/* Build SMF time from components */
#define MAKE_SMF_TIME(h,m,s)   (((h)*360000) + ((m)*6000) + ((s)*100))

/**
 * parse_smf_date - Extract year and day from SMF packed date
 * @smfdte: 4-byte SMF date field (0cyydddF format)
 * @year:   Output year (1900-2099)
 * @day:    Output day of year (1-366)
 */
static inline void parse_smf_date(const uint8_t smfdte[4], 
                                   int *year, int *day) {
    int century = (smfdte[0] & 0x0F);
    int yy = ((smfdte[1] >> 4) * 10) + (smfdte[1] & 0x0F);
    int ddd = ((smfdte[2] >> 4) * 100) + 
              ((smfdte[2] & 0x0F) * 10) + 
              (smfdte[3] >> 4);
    
    *year = (century == 0 ? 1900 : 2000) + yy;
    *day = ddd;
}

/*-------------------------------------------------------------------
 * Return code constants (generic)
 *-------------------------------------------------------------------*/

#define RC_OK                  0
#define RC_WARNING             4
#define RC_ERROR               8
#define RC_SEVERE              12
#define RC_CRITICAL            16

/*-------------------------------------------------------------------
 * Debugging support
 *-------------------------------------------------------------------*/

#ifdef DEBUG_EXITS

/* WTO - Write To Operator (requires __asm implementation) */
static inline void wto_msg(const char *msg, int len) {
    /* Simplified - real implementation needs WTO parameter list */
    __asm(
        " LA    1,%0                                     \n"
        " SVC   35                                       \n"
        : : "m"(*msg) : "0", "1", "14", "15"
    );
}

#define DEBUG_PRINT(msg) wto_msg(msg, sizeof(msg)-1)

#else

#define DEBUG_PRINT(msg)

#endif /* DEBUG_EXITS */

/*-------------------------------------------------------------------
 * Prolog/Epilog helpers
 *-------------------------------------------------------------------*/

/* Standard save area offsets */
#define SAVEAREA_BACK          4         /* +4  Back chain           */
#define SAVEAREA_FWD           8         /* +8  Forward chain        */
#define SAVEAREA_R14           12        /* +12 R14                  */
#define SAVEAREA_R15           16        /* +16 R15                  */
#define SAVEAREA_R0            20        /* +20 R0                   */
#define SAVEAREA_R1            24        /* +24 R1                   */
/* R2-R12 at +28 through +68 */

/* Common prolog/epilog patterns */
#define PROLOG_STD    "STM(14,12,12(13)),LR(12,15)"
#define EPILOG_STD    "LM(14,12,12(13)),BR(14)"

#define PROLOG_SAVE   "SAVE(14,12),LR(12,15)"
#define EPILOG_RETURN "RETURN(14,12)"

#endif /* METALC_BASE_H */
