/*********************************************************************
 * MODULE:    ICHPWX01
 * FUNCTION:  RACF Password Quality Exit
 *
 * Converted from: asm/RACF/ICHPWX01.asm
 * Source:         CBTTape File 728 (Dave Jousma)
 *
 * Password quality rules enforced:
 *   1) Password must be 8 characters (enforced by RACF externally)
 *   2) Password must contain at least one non-alphabetic character
 *   3) First/last characters must be non-numeric (enforced externally)
 *   4) Password not same as 10 previous (enforced by RACF externally)
 *   5) Password must not contain 4 consecutive chars of previous
 *   6) Password must not contain 3 identical adjacent characters
 *   7) Password must not contain user ID
 *   8) Password must not contain certain reserved words
 *
 * Exit Point: ICHPWX01 - RACF Password Verification Exit
 *
 * Build: Use IBM Metal C compiler with no LE dependencies
 *   xlc -qmetal -S ICHPWX01.c
 *   as -o ICHPWX01.o ICHPWX01.s
 *   ld -o ICHPWX01 ICHPWX01.o
 *
 * Attributes: REENTRANT, REUSABLE, AMODE 31, RMODE ANY
 *********************************************************************/

#include "metalc_base.h"
#include "metalc_racf.h"

/*===================================================================
 * PWXPL - Password Exit Parameter List
 * This is the standard IBM ICHPWXP mapping
 *===================================================================*/

#pragma pack(1)

struct pwxpl {
    void          *pwxcallr;          /* +0   Caller indicator ptr    */
    void          *pwxflag1;          /* +4   Flag byte 1 ptr         */
    void          *pwxusrid;          /* +8   User ID ptr (len prefix)*/
    void          *pwxcurpw;          /* +12  Current password ptr    */
    void          *pwxnewpw;          /* +16  New password ptr        */
    void          *pwxinstl;          /* +20  Installation data ptr   */
    void          *pwxgroup;          /* +24  Group name ptr          */
};

#pragma pack()

/* Caller indicator values */
#define PWXRINIT       0x00           /* Called by RACINIT            */
#define PWXPWORD       0x04           /* Called by PASSWORD command   */
#define PWXALTU        0x08           /* Called by ALTUSER command    */

/*===================================================================
 * Restricted Password Table - patterns to reject
 *===================================================================*/

static const char PASSTAB[][8] = {
    "JAN     ",
    "FEB     ",
    "MAR     ",
    "APR     ",
    "MAY     ",
    "JUN     ",
    "JUL     ",
    "AUG     ",
    "SEP     ",
    "OCT     ",
    "NOV     ",
    "DEC     ",
    "PASS    ",
    "TEST    ",
    "USER    ",
    "1234    ",
    "QWERTY  "
};

#define PASSNOE  (sizeof(PASSTAB) / sizeof(PASSTAB[0]))

/*===================================================================
 * Non-alphabetic character table (256 bytes)
 * Value is non-zero for non-alphabetic characters
 * Used for TRT-equivalent operation
 *===================================================================*/

static unsigned char is_non_alpha[256];

/*===================================================================
 * init_non_alpha_table - Initialize the non-alphabetic table
 *===================================================================*/

static void init_non_alpha_table(void) {
    /* Set all to non-zero (non-alphabetic) */
    for (int i = 0; i < 256; i++) {
        is_non_alpha[i] = 1;
    }

    /* Clear alphabetic characters (EBCDIC A-Z) */
    /* EBCDIC: A-I = 0xC1-0xC9, J-R = 0xD1-0xD9, S-Z = 0xE2-0xE9 */
    for (int i = 0xC1; i <= 0xC9; i++) is_non_alpha[i] = 0;  /* A-I */
    for (int i = 0xD1; i <= 0xD9; i++) is_non_alpha[i] = 0;  /* J-R */
    for (int i = 0xE2; i <= 0xE9; i++) is_non_alpha[i] = 0;  /* S-Z */
}

/*===================================================================
 * has_non_alpha - Check if password contains non-alphabetic char
 *
 * Input:  password - pointer to password (length-prefixed)
 * Output: 1 if contains non-alpha, 0 if all alphabetic
 *===================================================================*/

static int has_non_alpha(const unsigned char *password) {
    int len = password[0];
    const unsigned char *p = password + 1;

    for (int i = 0; i < len; i++) {
        if (is_non_alpha[p[i]]) {
            return 1;  /* Found non-alphabetic character */
        }
    }
    return 0;  /* All alphabetic - rule violated */
}

/*===================================================================
 * check_consecutive_previous - Rule 5
 * Password must not contain 4 consecutive chars of previous password
 *
 * Input:  newpw - new password (length-prefixed)
 *         curpw - current password (length-prefixed)
 * Output: 0 if OK, 1 if rule violated
 *===================================================================*/

static int check_consecutive_previous(const unsigned char *newpw,
                                       const unsigned char *curpw) {
    int newlen = newpw[0];
    int curlen = curpw[0];
    const unsigned char *np = newpw + 1;
    const unsigned char *cp = curpw + 1;

    /* Need at least 4 characters to check */
    if (newlen < 4 || curlen < 4) {
        return 0;  /* OK - too short to violate */
    }

    /* Check each 4-char substring of new password against old */
    for (int i = 0; i <= newlen - 4; i++) {
        for (int j = 0; j <= curlen - 4; j++) {
            if (memcmp_inline(&np[i], &cp[j], 4) == 0) {
                return 1;  /* Found 4 consecutive chars - violated */
            }
        }
    }

    return 0;  /* OK */
}

/*===================================================================
 * check_triple_chars - Rule 6
 * Password must not contain 3 identical adjacent characters
 *
 * Input:  password - password (length-prefixed)
 * Output: 0 if OK, 1 if rule violated
 *===================================================================*/

static int check_triple_chars(const unsigned char *password) {
    int len = password[0];
    const unsigned char *p = password + 1;

    /* Need at least 3 characters to check */
    if (len < 3) {
        return 0;  /* OK */
    }

    for (int i = 0; i <= len - 3; i++) {
        if (p[i] == p[i+1] && p[i] == p[i+2]) {
            return 1;  /* Found triple - violated */
        }
    }

    return 0;  /* OK */
}

/*===================================================================
 * check_contains_userid - Rule 7
 * Password must not contain the user ID
 *
 * Input:  password - password (length-prefixed)
 *         userid   - user ID (length-prefixed)
 * Output: 0 if OK, 1 if rule violated
 *===================================================================*/

static int check_contains_userid(const unsigned char *password,
                                  const unsigned char *userid) {
    int pwlen = password[0];
    int uidlen = userid[0];
    const unsigned char *pw = password + 1;
    const unsigned char *uid = userid + 1;

    /* If password is shorter than userid, can't contain it */
    if (pwlen < uidlen) {
        return 0;  /* OK */
    }

    /* Search for userid in password */
    for (int i = 0; i <= pwlen - uidlen; i++) {
        if (memcmp_inline(&pw[i], uid, uidlen) == 0) {
            return 1;  /* Found userid - violated */
        }
    }

    return 0;  /* OK */
}

/*===================================================================
 * get_entry_length - Get effective length of table entry
 * Returns length excluding trailing blanks
 *===================================================================*/

static int get_entry_length(const char *entry) {
    int len = 8;
    while (len > 0 && entry[len-1] == ' ') {
        len--;
    }
    return len;
}

/*===================================================================
 * check_reserved_words - Rule 8
 * Password must not contain reserved words
 *
 * Input:  password - password (length-prefixed)
 * Output: 0 if OK, 1 if rule violated
 *===================================================================*/

static int check_reserved_words(const unsigned char *password) {
    int pwlen = password[0];
    const unsigned char *pw = password + 1;

    for (int i = 0; i < (int)PASSNOE; i++) {
        int entlen = get_entry_length(PASSTAB[i]);

        /* If password is shorter than entry, skip */
        if (pwlen < entlen) {
            continue;
        }

        /* Search for reserved word in password */
        for (int j = 0; j <= pwlen - entlen; j++) {
            if (memcmp_inline(&pw[j], PASSTAB[i], entlen) == 0) {
                return 1;  /* Found reserved word - violated */
            }
        }
    }

    return 0;  /* OK */
}

/*===================================================================
 * ICHPWX01 - RACF Password Quality Exit Entry Point
 *
 * Input:  R1 -> PWXPL (Password Exit Parameter List)
 *
 * Return: 0 - Accept password
 *         4 - Reject (use RACF default message)
 *===================================================================*/

#pragma prolog(ICHPWX01, "SAVE(14,12),LR(12,15)")
#pragma epilog(ICHPWX01, "RETURN(14,12)")

int ICHPWX01(struct pwxpl *parm) {
    unsigned char caller;
    const unsigned char *newpw;
    const unsigned char *curpw;
    const unsigned char *userid;

    /* Initialize non-alpha table (first call) */
    static int initialized = 0;
    if (!initialized) {
        init_non_alpha_table();
        initialized = 1;
    }

    /*---------------------------------------------------------------
     * Check who is calling us. Only validate for RACINIT and
     * PASSWORD command. ALTUSER bypasses our checks.
     *---------------------------------------------------------------*/
    caller = *(unsigned char *)parm->pwxcallr;

    if (caller != PWXRINIT && caller != PWXPWORD) {
        /* Called by ALTUSER or other - accept without checking */
        return RACF_PWXRC_ACCEPT;
    }

    /*---------------------------------------------------------------
     * Check if new password was specified
     *---------------------------------------------------------------*/
    newpw = (const unsigned char *)parm->pwxnewpw;
    if (newpw == NULL || newpw[0] == 0) {
        /* No new password - accept */
        return RACF_PWXRC_ACCEPT;
    }

    /*---------------------------------------------------------------
     * Rule #2: At least one non-alphabetic character
     *---------------------------------------------------------------*/
    if (!has_non_alpha(newpw)) {
        wto_simple("ICHPWX02 Password must contain at least one non-alphabetic character", 67);
        return RACF_PWXRC_FAIL;
    }

    /*---------------------------------------------------------------
     * Rule #5: Not 4 consecutive chars of previous password
     *---------------------------------------------------------------*/
    curpw = (const unsigned char *)parm->pwxcurpw;
    if (curpw != NULL && curpw[0] > 0) {
        if (check_consecutive_previous(newpw, curpw)) {
            wto_simple("ICHPWX05 Password must not contain 4 consecutive characters of previous password", 80);
            return RACF_PWXRC_FAIL;
        }
    }

    /*---------------------------------------------------------------
     * Rule #6: Not 3 identical adjacent characters
     *---------------------------------------------------------------*/
    if (check_triple_chars(newpw)) {
        wto_simple("ICHPWX06 Password must not contain 3 identical adjacent characters", 66);
        return RACF_PWXRC_FAIL;
    }

    /*---------------------------------------------------------------
     * Rule #7: Password does not contain user ID
     *---------------------------------------------------------------*/
    userid = (const unsigned char *)parm->pwxusrid;
    if (userid != NULL && userid[0] > 0) {
        if (check_contains_userid(newpw, userid)) {
            wto_simple("ICHPWX07 Password must not contain your User ID", 47);
            return RACF_PWXRC_FAIL;
        }
    }

    /*---------------------------------------------------------------
     * Rule #8: Password does not contain reserved words
     *---------------------------------------------------------------*/
    if (check_reserved_words(newpw)) {
        wto_simple("ICHPWX08 Password has invalid character combination", 51);
        return RACF_PWXRC_FAIL;
    }

    /*---------------------------------------------------------------
     * All rules passed - accept the password
     *---------------------------------------------------------------*/
    return RACF_PWXRC_ACCEPT;
}
