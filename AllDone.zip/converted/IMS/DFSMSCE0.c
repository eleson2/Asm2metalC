/*********************************************************************
 * MODULE:    DFSMSCE0
 * FUNCTION:  TM and MSC Message Routing and Control Exit
 *
 * Converted from: asm/IMS/DFSMSCE0.asm
 *
 * This exit inspects MSC message routing and can override the
 * destination terminal. In this example, messages destined for
 * logical terminal 'TERM1' are rerouted to 'TERM2'.
 *
 * Exit Point: DFSMSCE0 - MSC Message Routing Exit
 *
 * Build: Use IBM Metal C compiler with no LE dependencies
 *   xlc -qmetal -S DFSMSCE0.c
 *   as -o DFSMSCE0.o DFSMSCE0.s
 *   ld -o DFSMSCE0 DFSMSCE0.o
 *
 * Installation: Link into IMS.SDFSRESL
 *********************************************************************/

#include "metalc_base.h"
#include "metalc_ims.h"

/*===================================================================
 * MSC Control Block Mappings (from assembler DSECTs)
 *===================================================================*/

/* MSC Function Codes */
#define MSC_FUNC_INIT          1     /* Initialization                */
#define MSC_FUNC_ROUTE         2     /* Message routing               */

#pragma pack(1)

/* MSCD - MSC Destination Block */
struct mscd {
    char           mscdname[8];      /* +0  Destination name          */
    uint8_t        mscdflg1;         /* +8  Type flags                */
};

/* MSCDFLG1 bits */
#define MSCD_LOG               0x01  /* Destination is an LTERM       */

/* MSCP - MSC Parameter List */
struct mscp {
    uint32_t       mscpfunc;         /* +0  Function code             */
    uint8_t        mscpflg1;         /* +4  Status flags              */
    uint8_t        _reserved[3];     /* +5  Reserved                  */
    struct mscd   *mscpdest;         /* +8  Pointer to destination    */
    void          *mscpmsga;         /* +12 Pointer to message prefix */
};

/* MSCPFLG1 bits */
#define MSCP_REQD              0x80  /* Reroute requested by exit     */

#pragma pack()

/*===================================================================
 * DFSMSCE0 - MSC Message Routing and Control Exit
 *
 * Called during MSC message processing to allow routing overrides.
 *
 * Input:
 *   parmlist - Standard OS parameter list
 *              parmlist[0] = address of MSCP
 *
 * Function codes:
 *   1 - Initialization
 *   2 - Message routing (inspect/modify destination)
 *
 * Return:
 *   0 - Continue (routing accepted or modified)
 *===================================================================*/

#pragma prolog(DFSMSCE0, "SAVE(14,12),LR(12,15)")
#pragma epilog(DFSMSCE0, "RETURN(14,12)")

int DFSMSCE0(void **parmlist) {
    struct mscp *parm;
    struct mscd *dest;

    /* Get MSCP parameter list */
    parm = (struct mscp *)parmlist[0];

    /* Route based on function code */
    switch (parm->mscpfunc) {

    case MSC_FUNC_INIT:
        /* Initialization - nothing to do */
        break;

    case MSC_FUNC_ROUTE:
        /* Message routing - inspect and possibly override */

        dest = parm->mscpdest;

        /* Only process logical terminal destinations */
        if (!(dest->mscdflg1 & MSCD_LOG)) {
            break;
        }

        /* If destination is 'TERM1', reroute to 'TERM2' */
        if (memcmp_inline(dest->mscdname, "TERM1   ", 8) == 0) {
            memcpy_inline(dest->mscdname, "TERM2   ", 8);
            BIT_SET(parm->mscpflg1, MSCP_REQD);  /* Tell IMS we modified dest */
        }

        break;

    default:
        /* Unknown function - ignore */
        break;
    }

    return IMS_RC_CONTINUE;
}
