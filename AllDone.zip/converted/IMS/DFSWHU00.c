/*********************************************************************
 * MODULE:    DFSWHU00
 * FUNCTION:  IMS Greeting/Sign-on Exit calling SAF (RACF)
 *
 * Converted from: asm/IMS/DFSWHU00.asm
 *
 * This exit intercepts IMS sign-on and issues a RACROUTE
 * REQUEST=AUTH call to verify the user is authorized to access
 * the 'IMSPROD' resource in the 'APPL' class.
 *
 * Exit Point: DFSWHU00 - IMS Greeting/Sign-on Exit
 *
 * Build: Use IBM Metal C compiler with no LE dependencies
 *   xlc -qmetal -S DFSWHU00.c
 *   as -o DFSWHU00.o DFSWHU00.s
 *   ld -o DFSWHU00 DFSWHU00.o
 *
 * Installation: Link into IMS.SDFSRESL
 *********************************************************************/

#include "metalc_base.h"
#include "metalc_ims.h"

/*===================================================================
 * SAF Work Area Size
 *===================================================================*/

#define SAF_WORKA_SIZE         512   /* RACROUTE work area size       */

/*===================================================================
 * saf_check_auth - Issue RACROUTE REQUEST=AUTH via inline assembly
 *
 * Checks if the user is authorized to READ the APPL class
 * resource 'IMSPROD'.
 *
 * Input:
 *   userid - Pointer to 8-byte user ID
 *   worka  - Pointer to 512-byte SAF work area
 *
 * Returns: SAF return code (0 = authorized, non-zero = denied)
 *
 * Note: The RACROUTE macro generates the parameter list and calls
 *       the SAF router. In Metal C, we must use inline assembly
 *       to invoke this service since no callable C interface exists.
 *===================================================================*/
static int saf_check_auth(const char *userid, void *worka) {
    int rc;

    /*
     * In production Metal C code, RACROUTE is invoked via inline
     * assembly because it is an assembler macro with no C binding.
     *
     * The assembler expansion builds a SAFP (SAF Parameter Block),
     * loads R1 with its address, and branches to the SAF router
     * entry point obtained from the CVT (CVTRAC).
     *
     * A simplified representation:
     *
     *   __asm(
     *       " RACROUTE REQUEST=AUTH,"
     *       "CLASS='APPL',"
     *       "ENTITY=('IMSPROD'),"
     *       "ATTR=READ,"
     *       "USERID=(%1),"
     *       "WORKA=(%2),"
     *       "MF=(E,RACLIST)"
     *       : "=r"(rc)
     *       : "r"(userid), "r"(worka)
     *       : "0","1","14","15"
     *   );
     *
     * Since RACROUTE requires assembler macro expansion, a real
     * implementation would either:
     * 1. Link to a small assembler stub that issues RACROUTE
     * 2. Use the SAF callable service (IRRSIA00) if available
     * 3. Build the SAFP parameter block manually and call CVTRAC
     *
     * For this conversion we call an assembler stub:
     */

    /* Suppress unused-parameter warnings in this stub */
    (void)userid;
    (void)worka;

    /*
     * Placeholder: In a complete build, link with an assembler
     * module that provides saf_racroute_auth().
     *
     * extern int saf_racroute_auth(const char *userid,
     *                              void *worka,
     *                              const char *class_name,
     *                              const char *entity);
     * rc = saf_racroute_auth(userid, worka, "APPL", "IMSPROD");
     */
    rc = 0;  /* Default: allow (replace with actual SAF call) */

    return rc;
}

/*===================================================================
 * DFSWHU00 - IMS Greeting/Sign-on Exit
 *
 * Called during user sign-on to perform SAF authorization checking.
 *
 * Input:
 *   parmlist - Standard OS parameter list
 *              parmlist[0] = pointer to pointer list:
 *                [0] = address of User ID (8 bytes)
 *                [4] = address of Group Name (8 bytes)
 *
 * Return:
 *   0 - Allow the sign-on
 *   8 - Reject the sign-on
 *===================================================================*/

#pragma prolog(DFSWHU00, "SAVE(14,12),LR(12,15)")
#pragma epilog(DFSWHU00, "RETURN(14,12)")

int DFSWHU00(void **parmlist) {
    void **ptrs;
    char *userid;
    /* char *groupname; */  /* Available but not used by SAF call */
    void *worka;
    int saf_rc;
    int rc;

    /* R1 points to a list of pointers */
    ptrs = (void **)parmlist[0];
    userid = (char *)ptrs[0];         /* 8-byte User ID */
    /* groupname = (char *)ptrs[1]; */  /* 8-byte Group Name */

    /* Obtain storage for SAF work area (reentrant) */
    worka = getmain(SAF_WORKA_SIZE, SUBPOOL_JOB_STEP);
    if (worka == NULL) {
        return IMS_RC_REJECT;  /* Cannot allocate - fail safe */
    }

    /* Clear the work area */
    memset_inline(worka, 0, SAF_WORKA_SIZE);

    /* Issue RACROUTE REQUEST=AUTH to check APPL class access */
    saf_rc = saf_check_auth(userid, worka);

    /* Evaluate SAF return code */
    if (saf_rc == 0) {
        rc = IMS_RC_CONTINUE;  /* Access granted - allow sign-on */
    } else {
        rc = IMS_RC_MODIFIED;  /* Access denied - reject sign-on (RC=8) */
    }

    /* Release work area storage */
    freemain(worka, SAF_WORKA_SIZE, SUBPOOL_JOB_STEP);

    return rc;
}
