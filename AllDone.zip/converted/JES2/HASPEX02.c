/*********************************************************************
 * MODULE:    HASPEX02
 * FUNCTION:  JES2 Exit 2 - JOB Statement Scan Exit
 *
 * Converted from: asm/JES2/HASPEX02.asm
 * Source:         CBTTape File 346 (Bob Break)
 *
 * This exit gets control when each JOB statement or JOB continuation
 * statement is processed and performs the following functions:
 *
 *   > Scan a JCL job card for a symbolic jobclass on the CLASS=
 *     keyword and convert the symbolic designation to a standard
 *     jobclass (A-Z, or 0-9).
 *
 *   > Scan a JCL job card for a symbolic msgclass on the MSGCLASS=
 *     keyword and convert the symbolic designation to a standard
 *     msgclass (A-Z, or 0-9).
 *
 * Exit Point: EXIT02 (JES2 Exit 2)
 *
 * Input registers (mapped to parameters):
 *   R0  - Code indicating type of job statement being scanned
 *         0 = initial JOB statement image
 *         4 = subsequent JOB statement continuation image
 *   R1  - Address of 3-word parameter list
 *   R10 - JCT address
 *   R11 - HCT address
 *   R13 - PCE address
 *
 * Return:
 *   R15 - Return code (0 = continue processing)
 *
 * Build: Use IBM Metal C compiler with no LE dependencies
 *   xlc -qmetal -S HASPEX02.c
 *   as -o HASPEX02.o HASPEX02.s
 *   ld -o HASPEX02 HASPEX02.o
 *********************************************************************/

#include "metalc_base.h"
#include "metalc_jes2.h"

/*===================================================================
 * Exit 2 Work Area
 *===================================================================*/

#pragma pack(1)

struct exit02_work {
    int32_t        retcode;          /* Return code                   */
    void          *jobbufp;          /* Job statement buffer pointer  */
    char           jclass;           /* Actual jobclass               */
    char           jobclass[8];      /* Symbolic jobclass             */
    int16_t        jclassl;          /* Symbolic jobclass length      */
    char           filler1;          /* Alignment                     */
    /* WTO message area */
    uint16_t       msgident;         /* Message identifier            */
    char           msgjobid[8];      /* Jobid from JCTJOBID           */
    char           msgfill1;         /* Separator                     */
    char           msgjnam[8];       /* Jobname from JCTJNAME         */
    char           msgfill2;         /* Separator                     */
    char           msgsymj[8];       /* Symbolic jobclass             */
};

#pragma pack()

/*===================================================================
 * Message Constants
 *===================================================================*/

#define MSG_ID         0x900F        /* Message identifier            */
#define MAX_SCAN_LEN   64            /* Maximum scan length           */

/*===================================================================
 * find_keyword - Search for keyword in buffer
 *
 * Input:
 *   buffer  - Pointer to JOB statement buffer
 *   keyword - Keyword to search for (e.g., ",CLASS=" or " CLASS=")
 *   keylen  - Length of keyword
 *   maxscan - Maximum characters to scan
 *
 * Returns: Pointer to value after keyword, or NULL if not found
 *===================================================================*/

static char *find_keyword(const char *buffer, const char *keyword,
                          int keylen, int maxscan) {
    for (int i = 0; i < maxscan; i++) {
        if (memcmp_inline(&buffer[i], keyword, keylen) == 0) {
            return (char *)&buffer[i + keylen];
        }
    }
    return NULL;
}

/*===================================================================
 * extract_symbolic_class - Extract symbolic class value
 *
 * Input:
 *   valptr - Pointer to start of value (after CLASS=)
 *   outbuf - Output buffer for symbolic class (8 bytes)
 *   outlen - Output length
 *
 * Returns: 1 if symbolic (length > 1), 0 if standard single-char
 *
 * Note: A standard class is a single character followed by blank or
 *       comma. A symbolic class is multiple characters.
 *===================================================================*/

static int extract_symbolic_class(const char *valptr, char *outbuf,
                                   int16_t *outlen) {
    int len = 0;

    /* Check if it's a single-character class */
    if (valptr[1] == ' ' || valptr[1] == ',') {
        /* Standard single-character class - not symbolic */
        return 0;
    }

    /* Extract symbolic class (up to 8 chars, stop at blank/comma) */
    while (len < 8 && valptr[len] != ' ' && valptr[len] != ',') {
        outbuf[len] = valptr[len];
        len++;
    }

    /* Pad with blanks */
    while (len < 8) {
        outbuf[len++] = ' ';
    }

    *outlen = len;
    return 1;  /* Symbolic class found */
}

/*===================================================================
 * issue_wto - Issue WTO message with symbolic class information
 *
 * Input:
 *   work - Work area with message fields filled in
 *===================================================================*/

static void issue_wto(struct exit02_work *work) {
    /*
     * Build message in work area:
     * Format: MSGID JOBID___ JOBNAME_ SYMCLASS
     *
     * In production JES2 exit, this would use $WTO macro.
     * Here we use the base wto_simple function.
     */
    char msgbuf[30];
    int pos = 0;

    /* Copy jobid */
    memcpy_inline(&msgbuf[pos], work->msgjobid, 8);
    pos += 8;
    msgbuf[pos++] = ' ';

    /* Copy jobname */
    memcpy_inline(&msgbuf[pos], work->msgjnam, 8);
    pos += 8;
    msgbuf[pos++] = ' ';

    /* Copy symbolic class */
    memcpy_inline(&msgbuf[pos], work->msgsymj, 8);
    pos += 8;

    /* Issue WTO (no routing codes for JES2 internal message) */
    wto_simple(msgbuf, pos);
}

/*===================================================================
 * HASPEX02 - JES2 Exit 2 Entry Point
 *
 * Scans JOB statement for symbolic CLASS= keyword and logs it.
 *
 * Input:
 *   stmt_type - 0 for initial JOB statement, 4 for continuation
 *   parmlist  - Parameter list pointer
 *   jct       - JCT (Job Control Table) pointer
 *   hct       - HCT (HASP Control Table) pointer
 *   pce       - PCE (Processor Control Element) pointer
 *
 * Returns: 0 to continue normal processing
 *===================================================================*/

#pragma prolog(HASPEX02, "SAVE(14,12),LR(12,15)")
#pragma epilog(HASPEX02, "RETURN(14,12)")

int HASPEX02(int stmt_type, void **parmlist, struct jct *jct,
             void *hct, void *pce) {
    struct exit02_work work;
    char *jobbuf;
    char *valptr;
    int rc = JES2_RC_CONTINUE;

    /* Suppress unused parameter warnings */
    (void)hct;
    (void)pce;

    /* Initialize work area */
    memset_inline(&work, 0, sizeof(work));

    /* Get job statement buffer pointer from parameter list */
    jobbuf = (char *)parmlist[0];
    work.jobbufp = jobbuf;

    /*-----------------------------------------------------------------
     * For continuation statements (stmt_type == 4), we still scan
     * as keywords may appear on continuations.
     *-----------------------------------------------------------------*/

    /*-----------------------------------------------------------------
     * Search for CLASS= keyword
     * Check both ",CLASS=" and " CLASS=" forms
     *-----------------------------------------------------------------*/
    valptr = find_keyword(jobbuf, ",CLASS=", 7, MAX_SCAN_LEN);
    if (valptr == NULL) {
        valptr = find_keyword(jobbuf, " CLASS=", 7, MAX_SCAN_LEN);
    }

    if (valptr == NULL) {
        /* No CLASS= keyword found - continue */
        return rc;
    }

    /*-----------------------------------------------------------------
     * CLASS= keyword found - check if it's a symbolic class
     *-----------------------------------------------------------------*/
    if (!extract_symbolic_class(valptr, work.jobclass, &work.jclassl)) {
        /* Standard single-character class - no action needed */
        return rc;
    }

    /*-----------------------------------------------------------------
     * Symbolic class found - log it via WTO
     *-----------------------------------------------------------------*/
    work.msgident = MSG_ID;

    /* Copy jobid from JCT */
    /* Note: JCT field JCTJOBID varies by JES2 version.
     * Here we format from jctjobid (numeric) to string.
     * In original asm, JCTJOBID was an 8-char field.
     */
    format_int(work.msgjobid, jct->jctjobid, 8);

    /* Copy jobname from JCT */
    memcpy_inline(work.msgjnam, jct->jctjname, 8);

    /* Copy symbolic jobclass */
    memcpy_inline(work.msgsymj, work.jobclass, 8);

    /* Issue WTO */
    issue_wto(&work);

    /*-----------------------------------------------------------------
     * Return to JES2 to continue processing
     * Note: Original exit did not modify the class - it only logged.
     * To actually convert symbolic to standard class, you would
     * set jct->jctjclas = translated_class here.
     *-----------------------------------------------------------------*/

    return rc;
}
