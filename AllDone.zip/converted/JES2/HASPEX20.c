/*********************************************************************
 * MODULE:    HASPEX20
 * FUNCTION:  JES2 Exit 20 - End of Job Input Exit
 *
 * Converted from: asm/JES2/HASPEX20.asm
 * Source:         CBTTape File 346 (Bob Break)
 *
 * This exit gets control at end of job input and performs the
 * following functions:
 *
 *   > Sets the JES2 reader time and date in the JQE and
 *     checkpoints the JQE.
 *
 *   > Forces batch jobs to output class "E".
 *
 * Exit Point: EXIT20 (JES2 Exit 20)
 *
 * Input registers (mapped to parameters):
 *   R0  - Code indicating:
 *         0 = Normal end of input
 *         4 = Job has JECL error
 *   R10 - JCT address
 *   R11 - HCT address
 *   R13 - PCE address
 *
 * Return:
 *   R15 - Return code (0 = continue processing)
 *
 * Build: Use IBM Metal C compiler with no LE dependencies
 *   xlc -qmetal -S HASPEX20.c
 *   as -o HASPEX20.o HASPEX20.s
 *   ld -o HASPEX20 HASPEX20.o
 *********************************************************************/

#include "metalc_base.h"
#include "metalc_jes2.h"

/*===================================================================
 * Exit 20 Work Area
 *===================================================================*/

#pragma pack(1)

struct exit20_work {
    char           ex20time[8];      /* Time (HHMMSSth format)        */
    char           ex20date[8];      /* Date (MMDDYYYY format)        */
};

#pragma pack()

/*===================================================================
 * Extended JQE fields for reader time/date
 * Note: Actual JQE layout varies by JES2 version
 *===================================================================*/

#pragma pack(1)

struct jqe_ext {
    char           jqeid[4];         /* 'JQE ' identifier             */
    uint16_t       jqejobid;         /* JES2 job number               */
    uint8_t        jqetype;          /* Queue type                    */
    uint8_t        jqeprio;          /* Queue priority                */
    uint8_t        jqeflg1;          /* Flag byte 1                   */
    uint8_t        jqeflg2;          /* Flag byte 2                   */
    uint8_t        jqeflg3;          /* Flag byte 3                   */
    uint8_t        jqeflg4;          /* Flag byte 4                   */
    void          *jqejct;           /* Pointer to JCT                */
    void          *jqenext;          /* Next JQE in queue             */
    void          *jqeprev;          /* Previous JQE in queue         */
    uint32_t       jqeqtime;         /* Time placed on queue          */
    uint32_t       jqeqdate;         /* Date placed on queue          */
    char           jqejname[8];      /* Job name (cached)             */
    char           jqejclas;         /* Job class (cached)            */
    uint8_t        _reserved1[3];    /* Reserved                      */
    /* Extended fields for reader time/date */
    char           jqerdron[8];      /* Reader on time                */
    char           jqerdton[8];      /* Reader on date                */
};

#pragma pack()

/* Zero constant for comparison */
static const char ZEROS[8] = {0, 0, 0, 0, 0, 0, 0, 0};

/*===================================================================
 * get_current_time - Get current time and date
 *
 * Output:
 *   time_out - 8-byte time field (HHMMSSth format)
 *   date_out - 8-byte date field (MMDDYYYY format)
 *
 * Note: In production, this would call the MVS TIME macro with
 *       DATETYPE=MMDDYYYY. Here we use a simplified implementation.
 *===================================================================*/

static void get_current_time(char *time_out, char *date_out) {
    uint64_t tod;
    uint32_t secs_today;
    int hours, mins, secs, hundredths;

    /* Get TOD clock */
    get_tod_clock(&tod);

    /*
     * TOD clock is microseconds since Jan 1, 1900.
     * Extract time of day portion.
     * This is a simplified calculation - production code should
     * use the TIME macro for accuracy.
     */
    secs_today = (uint32_t)((tod >> 12) % 86400000000ULL / 1000000);

    hours = secs_today / 3600;
    mins = (secs_today % 3600) / 60;
    secs = secs_today % 60;
    hundredths = (int)((tod >> 12) % 1000000 / 10000);

    /* Format time as HHMMSSth (packed decimal representation) */
    time_out[0] = '0' + (hours / 10);
    time_out[1] = '0' + (hours % 10);
    time_out[2] = '0' + (mins / 10);
    time_out[3] = '0' + (mins % 10);
    time_out[4] = '0' + (secs / 10);
    time_out[5] = '0' + (secs % 10);
    time_out[6] = '0' + (hundredths / 10);
    time_out[7] = '0' + (hundredths % 10);

    /*
     * Date calculation from TOD is complex.
     * In production, TIME macro returns date directly.
     * Here we use a placeholder - would need full date conversion.
     */
    memcpy_inline(date_out, "01012026", 8);  /* Placeholder */
}

/*===================================================================
 * update_jqe_time - Update JQE with reader time and date
 *
 * Input:
 *   jqe  - Pointer to JQE (extended)
 *   work - Work area with time/date values
 *
 * Note: In production JES2, this would use $DOGJQE macro to
 *       properly fetch, update, and checkpoint the JQE.
 *===================================================================*/

static void update_jqe_time(struct jqe_ext *jqe, struct exit20_work *work) {
    /*
     * Original assembler code:
     * 1. $DOGJQE ACTION=(FETCH,READ),JQE=PCEJQE
     * 2. Check if JQERDRON already set (skip if so)
     * 3. $QSUSE to acquire queue access
     * 4. $DOGJQE ACTION=(FETCH,UPDATE),JQE=PCEJQE
     * 5. MVC JQERDRON,EX20TIME
     * 6. MVC JQERDTON,EX20DATE
     * 7. $DOGJQE ACTION=RETURN,CBADDR=JQE
     *
     * In Metal C, we can directly update the fields, but in
     * production this should go through JES2 services.
     */

    /* Check if reader time already set */
    if (memcmp_inline(jqe->jqerdron, ZEROS, 8) != 0) {
        /* Already set - skip update */
        return;
    }

    /* Get current time and date */
    get_current_time(work->ex20time, work->ex20date);

    /* Update JQE fields */
    memcpy_inline(jqe->jqerdron, work->ex20time, 8);
    memcpy_inline(jqe->jqerdton, work->ex20date, 8);

    /*
     * In production, $DOGJQE ACTION=RETURN would checkpoint
     * the JQE update. Without proper JES2 integration, changes
     * would not persist across JES2 restart.
     */
}

/*===================================================================
 * HASPEX20 - JES2 Exit 20 Entry Point
 *
 * Called at end of job input to:
 * 1. Record reader time/date in JQE
 * 2. Force batch jobs to msgclass "E"
 *
 * Input:
 *   input_code - 0 for normal, 4 for JECL error
 *   jct        - JCT (Job Control Table) pointer
 *   hct        - HCT (HASP Control Table) pointer
 *   pce        - PCE (Processor Control Element) pointer
 *
 * Returns: 0 to continue normal processing
 *===================================================================*/

#pragma prolog(HASPEX20, "SAVE(14,12),LR(12,15)")
#pragma epilog(HASPEX20, "RETURN(14,12)")

int HASPEX20(int input_code, struct jct *jct, void *hct, struct pce *pce) {
    struct exit20_work work;
    struct jqe_ext *jqe;

    /* Suppress unused parameter warnings */
    (void)input_code;
    (void)hct;

    /* Initialize work area */
    memset_inline(&work, 0, sizeof(work));

    /*-----------------------------------------------------------------
     * Step 1: Update JQE with reader time and date
     *
     * Original code used $SUBIT to run RDRTIME routine in subtask
     * context to safely call TIME macro. In Metal C, we call
     * get_current_time directly (simplified).
     *-----------------------------------------------------------------*/
    jqe = (struct jqe_ext *)pce->pcejqe;
    if (jqe != NULL) {
        update_jqe_time(jqe, &work);
    }

    /*-----------------------------------------------------------------
     * Step 2: Force batch jobs to msgclass "E"
     *
     * Original code:
     *   CLI   JCTJOBID,C'J'      Check if batch job
     *   BNE   EXIT299            Skip if not (TSO/STC)
     *   MVI   JCTMCLAS,C'E'      Force msgclass E
     *
     * The original used first char of JCTJOBID to determine type:
     *   'J' = Batch job (JOBnnnnn)
     *   'T' = TSO user (TSOLnnnn)
     *   'S' = Started task (STCnnnnn)
     *-----------------------------------------------------------------*/

    /* Check if this is a batch job by examining first byte of jobid
     * Note: In the struct, jctjobid is numeric. Original asm had it
     * as a character field. Using flag-based check is more reliable.
     */
    if (jes2_is_batch(jct)) {
        /* Force batch job msgclass to 'E' */
        jct->jctmclas = JES2_CLASS_E;
    }

    /*-----------------------------------------------------------------
     * Return to JES2 to continue normal processing
     *-----------------------------------------------------------------*/
    return JES2_RC_CONTINUE;
}
